##' @title A class for download objects.
##'
##' @description A \code{download} is an object with the full record for a single dataset.
##'
##' @details TO DO
##'
##' @author Simon Goring
##' @name download
##' @keywords methods
NULL

