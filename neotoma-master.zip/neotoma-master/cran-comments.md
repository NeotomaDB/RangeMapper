## Test Environments
+   [windows passes](https://win-builder.r-project.org/kW84zThxQgh8/00check.log).
+   Linux - [Travis](https://travis-ci.org/ropensci/neotoma/builds/433268215?utm_source=github_status&utm_medium=notification) tests are passing.
+   [Appveyor](https://ci.appveyor.com/project/sckott/neotoma/build/1.0.1397) tests are passing.

## R CMD check results:
+   R CMD check succeeded (0 errors, warnings, notes)
+   Travis gives no notes.
+   Appveyor passes

## Downstream Dependencies:
NA
